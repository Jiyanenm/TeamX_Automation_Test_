package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MainPage {

    WebDriver driver;

    public MainPage(WebDriver driver)
    {
        this.driver = driver;
    }

    By agricultureDropDown = By.xpath("//*[@id=\"nav-drawer\"]/div/div[1]/div/div/select/option[3]");
    By userManagement = By.xpath("//*[@id=\"nav-drawer\"]/div/nav/div[11]/nav/button/div");
    By addUserButton = By.cssSelector("#egdsbloa4 > div:nth-child(2) > div > div");
    By userTypeDropDown = By.name("SubmitUserCommand.UserTypeId");
    By title = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic155-dynamic-input-select-dynamic-inputselect-select-form-select\"]");
    By firstName = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic156-dynamic-input-input-dynamic\"]");
    By lastName = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic168-dynamic-input-input-dynamic\"]");
    By yourSelfUserName = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic168-dynamic-input-input-dynamic\"]");
    By emailAddress = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic158-dynamic-input-email-dynamic\"]");
    By mobileNumber = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic159-dynamic-input-phone-number-dynamic\"]");
    By startDate = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic162-dynamic-input-datetime-dynamic-input-date-date-picker\"]");
    By defaultProfileUser = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic165-dynamic-input-select-dynamic-inputselect-select-form-select\"]");
    By timeZone = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic19-dynamic-input-select-dynamic-inputselect-select-form-select\"]");
    By language = By.xpath("//*[@id=\"user-settings-add-user-settings-renderer-dynamic164-dynamic-input-select-dynamic-inputselect-select-form-select\"]");
    By createButton = By.id("view-user-button-create");

    public void navigateToMainPage() throws InterruptedException {
        driver.wait(50000);
        driver.findElement((agricultureDropDown)).click();
        driver.findElement((userManagement)).click();
        driver.findElement((addUserButton)).click();
        driver.findElement((userTypeDropDown)).click();
    }
    public void completeUserForm() throws InterruptedException {
        driver.wait(50000);
        driver.findElement((title)).sendKeys(("Mr"));
        driver.findElement((firstName)).sendKeys(("Tester Nathi"));
        driver.findElement((lastName)).sendKeys(("Jiyane Tester"));
        driver.findElement((yourSelfUserName)).sendKeys(("NMTester"));
        driver.findElement((emailAddress)).sendKeys(("testernm@gmail.com"));
        driver.findElement((mobileNumber)).sendKeys(("0731234560"));
        driver.findElement((startDate)).sendKeys(("2026/07/15"));
        driver.findElement((defaultProfileUser)).sendKeys(("Acoustex Trim cc (Invoice Test)"));
        driver.findElement((timeZone)).sendKeys(("//*[@id=\"user-settings-add-user-settings-renderer-dynamic19-dynamic-input-select-dynamic-inputselect-select-form-select\"]"));
        driver.findElement((language)).sendKeys(("English"));

        driver.findElement((createButton)).click();
    }

}
