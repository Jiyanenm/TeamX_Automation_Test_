package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

        WebDriver driver;

        public LoginPage(WebDriver driver)
        {
            this.driver = driver;
        }

        By username = By.xpath("//*[@id=\"login-input-username\"]");
        By password = By.xpath("//*[@id=\"login-input-password\"]");
        By buttonLogin = By.xpath("//*[@id=\"login-button-submit\"]");
        By buttonLogOut = By.xpath("//*[@id=\"user-context-menu-logout\"]/p");
        public void login(String user, String pass)
        {
            try {

                driver.wait(50000);
                driver.findElement((username)).sendKeys((user));
                driver.wait(50000);
                driver.findElement((password)).sendKeys((pass));
                driver.wait(50000);
                driver.findElement((buttonLogin)).click();
                driver.wait(50000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }
        public  void logout() throws InterruptedException {
            driver.wait(50000);
            driver.findElement((buttonLogOut)).click();
        }
}
