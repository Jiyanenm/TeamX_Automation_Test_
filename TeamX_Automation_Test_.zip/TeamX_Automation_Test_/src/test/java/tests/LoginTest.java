package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

import java.util.logging.Logger;

public class LoginTest extends BaseTest {

    @Test
    public void LoginTestSuccessfully()
    {
        try
        {
            LoginPage loginPage = new LoginPage(driver);

            loginPage.login("tester12","P@ssword123"); //These values are hard coded only for assignment purpose,later I can read it from config files or feature files.

            Assert.assertTrue(driver.getCurrentUrl().contains("https://devweb.trenstar.co.za/teamx/Account/Login?ReturnUrl=%2Fteamx"));

          //  driver.close();
        }
        catch (Exception err)
        {
            System.out.println("Error " + err);
            Logger.getLogger(err.toString());
        }


    }
}
