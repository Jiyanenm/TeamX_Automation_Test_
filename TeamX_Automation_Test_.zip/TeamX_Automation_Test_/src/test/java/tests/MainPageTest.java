package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.MainPage;

import java.util.logging.Logger;

public class MainPageTest extends BaseTest {

    @Test
    public void testMainPage()
    {

        try
        {
            MainPage mainPage = new MainPage(driver);
            LoginPage loginPage = new LoginPage(driver);

            loginPage.login("tester12","P@ssword123");

            mainPage.navigateToMainPage();

            mainPage.completeUserForm();

            Assert.assertEquals("User created successfully.","User created successfully.","User created successfully.");

        }
        catch(Exception error)
        {
            System.out.println("Error " + error);
            Logger.getLogger(error.toString());
        }
    }
}
